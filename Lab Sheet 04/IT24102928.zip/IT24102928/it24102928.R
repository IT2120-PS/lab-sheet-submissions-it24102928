setwd("C:\\Users\\it24102928\\Desktop\\IT24102928")
getwd()

data<-read.table("DATA 4.txt",header=TRUE,sep= " ")
fix(data)
attach(data)

boxplot(x1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(x1,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(x1,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)

hist(x1,ylab="Frequency",xlab="Team Attendence",main="Histogram for Team Attendance")
hist(x2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(x3,ylab="Frequency",xlab="Team Years",main="Histogram for YEars")

stem(x1)
stem(x2)
stem(x3)

mean(x1)
mean(x2)
mean(x3)

median(x1)
median(x2)
median(x3)

sd(x1)
sd(x2)
sd(x3)

summary(x1)
summary(x2)
summary(x3)

quantile(x1)

quantile(x1)[2]

quantile(x1)[4]

IQR(x1)
IQR(x2)
IQR(x3)

get.mode<-function(y){
  count<-table(x3)
  name(counts[counts == max(counts)])
}

get.mode(x3)

table(x3)

max(counts)

counts == max(counts)

counts[counts == max(counts)]

names(counts[counts == max(counts)])

get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 -q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound =",ub))
  print(paste("lower Bound =",lb))
  print(paste("Outliers:",paste(sort(z[z<lb | z>ub]),collapse = ",")))
}

get.outliers(x1)
get.outliers(x2)
get.outliers(x3)

#exercise
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
str(branch_data)
summary(branch_data)

boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales")

fivenum(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

outliers_years <- find_outliers(branch_data$Years_X3)
outliers_years

